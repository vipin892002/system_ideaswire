import os
import cv2
import dlib
import sys
from skimage import io
import numpy as np
from scipy.misc import imresize
import Image


def detection_test():
	count =0
	img_count = 0
	tem2 = 0
	detector = dlib.get_frontal_face_detector()
	root_dir = '../data/videos'
	name_list = os.listdir(root_dir)
	print len(name_list)
	for x in range(len(name_list)):
		name_path = os.path.join(root_dir, name_list[x])
		print name_path
		image_list = os.listdir(name_path)
		for y in range(len(image_list)):
			image_path = os.path.join(name_path, image_list[y])
			image = cv2.imread(image_path)
			img_count = img_count + 1
			dets = detector(image, 0)
			if dets:
				count = count + 1
			else:
				tem2 = tem2 + 1

			for i, d in enumerate(dets):
				left = d.left()
				top = d.top()
				bottom = d.bottom()
				rit = d.right()
				temp = image[top-5:bottom+5, left-5:rit+5]
				crop_image = imresize(temp, (47,55))
				cv2.imwrite(dest_new_path + '/' + name_list[x]+'_'+str(count)+'.jpg', crop_image)
				print 'image saved'
				#cv2.imshow('jkjk', crop_image)
				#cv2.waitKey()

	print count
	print img_count
	print tem2


if __name__ == '__main__':
	detection_test()