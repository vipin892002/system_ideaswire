import os
import cv2
import dlib
import sys
from skimage import io
import numpy as np
from scipy.misc import imresize


def face_crop_from_video():
	
	detector = dlib.get_frontal_face_detector()
	#win = dlib.image_window()
	count = 0
	video_name = os.listdir('../data/videos')
	for x in video_name:
		name = x.split('.')
		video_path = os.path.join('../data/videos', x)
		cap = cv2.VideoCapture(video_path)
		success, image = cap.read()	
		while success:
			success, image = cap.read()
			if success:
				image = np.rot90(image, 3)
				dets = detector(image, 0)
				for i, d in enumerate(dets):
					left = d.left()
					top = d.top()
					bottom = d.bottom()
					rit = d.right()
					temp = image[top-5:bottom+5, left-5:rit+5]
					crop_image = imresize(temp, (47,55))
					#cv2.imshow('njsdn', crop_image)
					#cv2.waitKey()					
		
					dest_path = '../data/crop_img/' + str(name[0]) + '/0'
					if not os.path.exists(dest_path):
						os.mkdir(dest_path)

					save_path = dest_path + '/' + str(count) + '.jpg'
					cv2.imwrite(save_path, crop_image)
					count = count + 1



				'''
				rows,cols, x = image.shape
				M = cv2.getRotationMatrix2D((cols/2,rows/2),270,1)
				dst = cv2.warpAffine(image,M,(cols,rows))
				try:
					crop_face = fd.vector_img(dst)
					dest_path = '../data/crop_img/' + str(name[0]) + '/0'
					if not os.path.exists(dest_path):
						os.mkdir(dest_path)

					save_path = dest_path + str(count) + '.jpg'
					cv2.imwrite(save_path, crop_face)
					print 'save_path'
				except:
					print 'exception video frame ended or face not detected'

				'''



if __name__ == '__main__':
	face_crop_from_video()