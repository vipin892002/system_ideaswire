import os
from annoy import AnnoyIndex
import numpy as np
import pandas as pd
import cPickle



deepid_path = './cnn/deepid'
annoy_path = './annoy/test_annoy.ann'
label_count_path = './annoy/annoy_label.csv'
'''
f = 160
t = AnnoyIndex(f, metric = 'angular')
count = 0
label_list = []
deepid_list = os.listdir(deepid_path)
deepid_list.sort()
for x in range(len(deepid_list)):
	deepid_csv = deepid_path + '/' + deepid_list[x]
	data = pd.read_csv(deepid_csv, sep = ',', header = None)
	data = np.asarray(data)
	x_data, y_data = data.shape
	for y in range(x_data):
		tem_data = data[y]
		deepid = tem_data[:160]
		label = tem_data[160]
		label = int(label)
		t.add_item(count, deepid.astype(np.int32))
		count = count + 1
		label_list.append(label)

t.build(1000)
t.save(annoy_path)
f = open(label_count_path, 'wb')
for x in label_list:
	f.write(str(x))
	f.write('\n')
f.close()

print '***************DONE***************'

'''

def deepid_pkl():

	t = AnnoyIndex(160, metric = 'eucledian')
	count = 0
	label_list = []
	deepid_file_list = os.listdir(deepid_path)
	for x in deepid_file_list:
		deepid_file = os.path.join(deepid_path, x)
		data = open(deepid_file)
		data = cPickle.load(data)
		tem_deepid_list = data[0]
		tem_label_list = data[1]
		for y in range(len(tem_deepid_list)):
			ann_deepid = tem_deepid_list[y]
			ann_label = tem_label_list[y]
			ann_label = int(ann_label)
			print ann_deepid
			#print ann_label
			t.add_item(count, ann_deepid.astype(np.int32))
			count = count + 1
			label_list.append(ann_label)
	

	t.build(1000)
	t.save(annoy_path)
	f = open(label_count_path, 'wb')
	for z in label_list:
		f.write(str(z))
		f.write('\n')
	f.close()
	print '***********done***********'
	

if __name__ == '__main__':
	deepid_pkl()