import numpy as np
import cv2
from scipy.misc import imresize

def outsource(img_path):
    face_cascade = cv2.CascadeClassifier("/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml")

    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    count  = 0

    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),0)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = gray[y:y+h, x:x+w]
        #temp = img[y:y+h+5,x:x+w+5]
        temp = img[y-5:y+h+5, x-5:x+w+5]
        ''' x = x -5 and y = y-5 before croping'''
        t2 = imresize(temp, (47,55))
        #cv2.imshow('ncdkcdmc', t2)
        #cv2.waitKey()
        #cv2.imwrite(dest_path + '/' + str(img_name) + '_' +str(count)+'.jpg',t2)
        count = count+1
        return t2

def vector_img(img):
    face_cascade = cv2.CascadeClassifier("/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    count  = 0

    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),0)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = gray[y:y+h, x:x+w]
        #temp = img[y:y+h+5,x:x+w+5]
        temp = img[y-5:y+h+5, x-5:x+w+5]
        ''' x = x -5 and y = y-5 before croping'''
        t2 = imresize(temp, (47,55))
        #cv2.imshow('ncdkcdmc', t2)
        #cv2.waitKey()
        #cv2.imwrite(dest_path + '/' + str(img_name) + '_' +str(count)+'.jpg',t2)
        count = count+1
        return t2
