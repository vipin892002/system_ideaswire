import numpy as np
import cv2
from scipy.misc import imresize
import os
import Image

def outsource(img_path):
    #print img_path
    '''
    face_cascade = cv2.CascadeClassifier("/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml")
    flag = 0
    img = cv2.imread(img_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    '''
    img = cv2.imread(img_path)
    '''opening full imgae'''
    #img = Image.open(img_path)
    arr_img = np.asarray(img, dtype='float64')
    #print arr_img
    #print arr_img.shape
    #print arr_img
    face_cascade = cv2.CascadeClassifier("/usr/local/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml")
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    
    faces = face_cascade.detectMultiScale(gray, 1.5, 5)
    
    #faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    #print faces
    count  = 0

    for (x,y,w,h) in faces:
        cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),0)
        roi_gray = gray[y:y+h, x:x+w]
        roi_color = gray[y:y+h, x:x+w]
        temp = img[y:y+h,x:x+w]
        t2 = imresize(temp, (47,55))
        #print t2
        #print t2.shape
        cv2.imshow('test', t2)
        cv2.waitKey()
        return t2