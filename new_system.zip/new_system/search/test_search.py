import os
import numpy as np
import cv2
import pandas as pd
import dlib
import sys
from skimage import io
import numpy as np
from scipy.misc import imresize
import search_deepid_generate as deepid_generate
from annoy import AnnoyIndex
import Image




def test_ann():

	acc_csv_file = '../new_System_Result.csv'
	sys_result = open(acc_csv_file, 'a')
	label_csv_path = '../train/cnn/csv/train.csv'
	original_label_csv = pd.read_csv(label_csv_path, sep = ',', header = None)
	original_label_csv = np.asarray(original_label_csv)
	
	count = 0
	annoy_path = '../search/annoy/test_annoy.ann'
	annoy_label = '../search/annoy/annoy_label.csv'

	p1 = AnnoyIndex(160, metric = 'eucledian')
	p1.load(annoy_path)

	image_size = (3, 55, 47)
	image_vector_len = np.prod(image_size)

	detector = dlib.get_frontal_face_detector()

	test_root = os.listdir('../data/test_images')
	for x in test_root:
		class_name = os.path.join('../data/test_images', x)
		test_img = os.listdir(class_name)
		for y in test_img:
			#if 'vai' in y:
			image_test = os.path.join(class_name, y)
			image = cv2.imread(image_test)

			#print image_test
			original_name = image_test.split('/')
			original_name = original_name[-2]

			for h in original_label_csv:
				h = str(h)
				if original_name in h:
					#print h
					original_label = h[-2]
					original_label = int(original_label)					

			dets = detector(image, 0)
			if dets:
				
				for i, d in enumerate(dets):
					left = d.left()
					top = d.top()
					bottom = d.bottom()
					rit = d.right()
					face_crop = image[top-50:bottom+10, left-10:rit+10]
					face_crop = imresize(face_crop, (47,55))
					cv2.imwrite('../data/test_image_face/' + str(count) +'.jpg', face_crop)
					
					#cv2.imshow('test', face_crop)
					
					face_crop = Image.open('../data/test_image_face/' + str(count) + '.jpg')
					face_crop = np.asarray(face_crop, dtype='float64')
					face_crop = face_crop.transpose(2,0,1).reshape((image_vector_len, ))
					face_crop = np.asarray(face_crop, dtype='float64')
					count +=1

					deepid = deepid_generate.outsource(face_crop)
	        		#print deepid
	        		
					a1 = deepid[0]

					n = p1.get_nns_by_vector(a1.astype(np.int32), 100, -1, True)

					label_data = pd.read_csv(annoy_label, sep = ',', header = None)
					label_data = np.asarray(label_data)
					tes = n[0]
					label_old = []
					temp_label_list = []
					for z in range(len(tes)):
						label = label_data[tes[z]]
						if label not in label_old:
							label = int(label)
							temp_label_list.append(label)
							label_old.append(label)
					#print n
					#print temp_label_list
					flag = 0
					for k in range(len(temp_label_list)):
						if flag == 1:
							break
						else:
							if original_label == temp_label_list[k]:
								ann_lab = k+1
								print image_test
								print original_name
								print original_label
								print ann_lab
								line = str(original_name) + ',' +  str(image_test) +  ',' + str(original_label) + ',' + str(ann_lab) + ',' + str(len(temp_label_list))
								sys_result.write(line)
								sys_result.write('\n')
								flag += 1
								print line

							else:

								line = str(original_name) + ',' + str(image_test) + ',' + str(original_label) + ',' + str('IMAGE NOT FOUND')
								sys_result.write(line)
								sys_result.write('\n')
								flag += 1
								print line
	        				#cv2.waitKey()

    		else:
    			line = str(image_test) + ',' + str('FACE NOT DETECTED') + '\n'
    			sys_result.write(line)


	sys_result.close()

if __name__ == '__main__':
	test_ann()