import os
import Image
import numpy as np
import search_deepid_generate as deepid_generate
from annoy import AnnoyIndex
import search_detection_crop as detection_crop
import time
import cPickle
import cv2
import pandas as pd

start_time = time.clock()

search_image_path = '/media/rahul/42d36b39-1ad7-45d4-86bb-bf4e0a66a97f/new_system/data/test_images/rahul/rahul_05.jpg'
#new_search_path = '/media/rahul/42d36b39-1ad7-45d4-86bb-bf4e0a66a97f/Data Sets/part2'
annoy_path = './annoy/test_annoy.ann'
image_size = (3, 55, 47)

p1 = AnnoyIndex(160, metric = 'angular')
p1.load(annoy_path)

'''
def temp_test(new_search_path):
	csv_path = '/home/rahul/Desktop/xyz.csv'
	in_tem = os.listdir(new_search_path)
	f = open(csv_path, 'a')
	for x in range(100):
		abc = os.path.join(new_search_path, in_tem[x])
		kkk = os.listdir(abc)
		for y in range(5):#len(kkk)):
			print kkk[y]
			crop_img = os.path.join(abc, kkk[y])
			result = search_image(crop_img)
			ann_label = result[0]
			dist = result[1]
			ori = kkk[y]
			print result, kkk[y]
			line = str(ann_label) + ',' + str(dist) + ',' + str(ori)
			f.write(line)
			f.write('\n')
	f.close
'''


def search_image(search_image_path):
	#dest_crop_path = '/media/rahul/42d36b39-1ad7-45d4-86bb-bf4e0a66a97f/Fresh Exp/search_400/crop_img/teet.jpg'
	#label_ann = open('/media/rahul/42d36b39-1ad7-45d4-86bb-bf4e0a66a97f/retry/video data/annoy/test.pkl', 'rb')
	#data2 = cPickle.load(label_ann)
	#print len(data2)
	#print data2
	#ddvffdf
	image_vector_len = np.prod(image_size)
	#image = Image.open(search_image_path)
	#image = cv2.imread(search_image_path)
	image = detection_crop.outsource(search_image_path)
	#cv2.imwrite(dest_crop_path, image)

	#image_new = Image.open(dest_crop_path)
	img_arr = np.asarray(image, dtype = 'float64')
	#print img_arr
	#print img_arr.shape
	img_arr = img_arr.transpose(2,0,1).reshape((image_vector_len, ))
	#print img_arr
	#img_arr = np.asarray(img_arr, dtype='float64')
	
	deepid = deepid_generate.outsource(img_arr)
	#deepid_write(deepid)
	a1 = deepid[0]
	#print a1

	n = p1.get_nns_by_vector(a1.astype(np.int32), 50, -1, True)
	#print n
	temp_path = './annoy/annoy_label.csv'
	da = pd.read_csv(temp_path, sep = ',', header = None)
	da = np.asarray(da)

	return da[n[0]], n

	'''
	for y in range(0, 9):
		print da[n[0][y]]
	return n
	#print n
	
	if n[0]:
		print 'CORRECT LABEL IS :\t', n[0]
		print 'DISTANCE', n[1]
	else:
		print 'IMAGE NOT FOUND IN OUR DATABASE'
	return str(int(np.array(n[0])))


def deepid_write(deepid):
	deep = deepid[0]
	save_path = '/home/rahul/Desktop/test/test.csv'
	file_save = open(save_path, 'wb')
	for x in deep:
		line = str(x) + ','
		file_save.write(line)
	file_save.write('\n')
	file_save.close()
'''



if __name__ == '__main__':
	result, di = search_image(search_image_path)
	print result
	print di[1]
	#temp_test(new_search_path)
	end_time = time.clock()

	total_time = end_time - start_time
	#print 'TOTAL TIME FOR SEARCH :-\t', total_time
	